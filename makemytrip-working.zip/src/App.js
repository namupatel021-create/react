import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from "react-router-dom";

const flights = [
  { id: 1, from: "Ahmedabad", to: "Delhi", price: 3500 },
  { id: 2, from: "Mumbai", to: "Bangalore", price: 4500 }
];

const hotels = [
  { id: 1, name: "Taj Hotel", city: "Mumbai", price: 5000 },
  { id: 2, name: "Leela Palace", city: "Delhi", price: 7000 }
];

function Navbar({ cart }) {
  return (
    <nav style={{display:"flex",justifyContent:"space-between",padding:"10px",background:"#007bff",color:"white"}}>
      <div>
        <Link to="/" style={{marginRight:"10px",color:"white"}}>Flights</Link>
        <Link to="/hotels" style={{marginRight:"10px",color:"white"}}>Hotels</Link>
        <Link to="/cart" style={{color:"white"}}>Cart ({cart.length})</Link>
      </div>
      <Link to="/login" style={{color:"white"}}>Login</Link>
    </nav>
  );
}

function Login({ setAuth }) {
  const login = () => {
    localStorage.setItem("user", "true");
    setAuth(true);
  };
  return (
    <div style={{padding:"20px"}}>
      <h2>Login</h2>
      <button onClick={login}>Login</button>
    </div>
  );
}

function PrivateRoute({ children, auth }) {
  return auth ? children : <Navigate to="/login" />;
}

function Flights({ addToCart }) {
  return (
    <div style={{padding:"20px"}}>
      <h2>Flights</h2>
      {flights.map(f => (
        <div key={f.id} style={{border:"1px solid #ccc",margin:"10px",padding:"10px"}}>
          {f.from} → {f.to} - ₹{f.price}
          <br/>
          <button onClick={() => addToCart(f)}>Book</button>
        </div>
      ))}
    </div>
  );
}

function Hotels({ addToCart }) {
  return (
    <div style={{padding:"20px"}}>
      <h2>Hotels</h2>
      {hotels.map(h => (
        <div key={h.id} style={{border:"1px solid #ccc",margin:"10px",padding:"10px"}}>
          {h.name} ({h.city}) - ₹{h.price}
          <br/>
          <button onClick={() => addToCart(h)}>Book</button>
        </div>
      ))}
    </div>
  );
}

function Cart({ cart, removeFromCart }) {
  return (
    <div style={{padding:"20px"}}>
      <h2>My Bookings</h2>
      {cart.length === 0 ? <p>No bookings</p> : cart.map((item,i)=>(
        <div key={i} style={{display:"flex",justifyContent:"space-between",borderBottom:"1px solid #ccc"}}>
          <span>{item.from ? item.from + " → " + item.to : item.name}</span>
          <button onClick={()=>removeFromCart(i)}>Cancel</button>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [cart, setCart] = useState([]);
  const [auth, setAuth] = useState(localStorage.getItem("user") === "true");

  const addToCart = (item) => setCart([...cart, item]);
  const removeFromCart = (i) => {
    const updated = [...cart];
    updated.splice(i,1);
    setCart(updated);
  };

  return (
    <Router>
      <Navbar cart={cart}/>
      <Routes>
        <Route path="/" element={<Flights addToCart={addToCart}/>}/>
        <Route path="/hotels" element={<Hotels addToCart={addToCart}/>}/>
        <Route path="/login" element={<Login setAuth={setAuth}/>}/>
        <Route path="/cart" element={
          <PrivateRoute auth={auth}>
            <Cart cart={cart} removeFromCart={removeFromCart}/>
          </PrivateRoute>
        }/>
      </Routes>
    </Router>
  );
}
