
'use client';
import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'next/navigation';
import { listings } from '../../data/listings';

export default function Property(){
  const params = useParams();
  const item = listings.find(l => l.id === params.id);

  const [checkIn,setCheckIn] = useState("");
  const [checkOut,setCheckOut] = useState("");
  const [bookings,setBookings] = useState([]);
  const [msg,setMsg] = useState("");

  useEffect(()=>{
    const saved = localStorage.getItem('bookings');
    if(saved) setBookings(JSON.parse(saved));
  },[]);

  const nights = useMemo(()=>{
    if(!checkIn || !checkOut) return 0;
    const n = (new Date(checkOut) - new Date(checkIn))/(1000*60*60*24);
    return n>0?n:0;
  },[checkIn,checkOut]);

  const total = nights * (item?.price || 0);

  const isConflict = () => {
    const hotelBookings = bookings.filter(b => b.id === item.id);
    let roomsUsed = 0;
    hotelBookings.forEach(b => {
      const overlap = !(new Date(checkOut) <= new Date(b.checkIn) || new Date(checkIn) >= new Date(b.checkOut));
      if(overlap) roomsUsed++;
    });
    return roomsUsed >= item.rooms;
  };

  const reserve = () => {
    if(!checkIn || !checkOut) return setMsg("Select dates");
    if(new Date(checkOut) <= new Date(checkIn)) return setMsg("Invalid dates");
    if(isConflict()) return setMsg("❌ No rooms available");

    const newB = { id:item.id, title:item.title, checkIn, checkOut, nights, total };
    const updated = [...bookings, newB];
    setBookings(updated);
    localStorage.setItem('bookings', JSON.stringify(updated));
    setMsg("🎉 Thank you for booking!");
    setCheckIn(""); setCheckOut("");
  };

  if(!item) return <div className="container">Not found</div>;

  return (
    <div className="container">
      <h1 style={{marginBottom:10}}>{item.title}</h1>

      {/* Gallery */}
      <div className="gallery">
        {item.images.slice(0,4).map((src,i)=>(
          <img key={i} src={src} />
        ))}
      </div>

      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:20,marginTop:20}}>
        <div>
          <h3>About</h3>
          <p>Beautiful stay in {item.city} with premium amenities.</p>

          <h3>Amenities</h3>
          <div className="row" style={{flexWrap:"wrap"}}>
            {item.amenities.map((a,i)=>(
              <span key={i} className="badge" style={{background:"#eee",color:"#111"}}>{a}</span>
            ))}
          </div>

          <h3 style={{marginTop:20}}>Your bookings</h3>
          {bookings.filter(b=>b.id===item.id).map((b,i)=>(
            <p key={i}>• {b.checkIn} → {b.checkOut} (₹{b.total})</p>
          ))}
        </div>

        {/* Booking Panel */}
        <div className="panel">
          <div className="space">
            <h3 style={{margin:0}}>₹{item.price}</h3>
            <span>/night</span>
          </div>

          <div style={{marginTop:10}}>
            <div className="row">
              <input className="input" type="date" value={checkIn} onChange={e=>setCheckIn(e.target.value)} />
              <input className="input" type="date" value={checkOut} onChange={e=>setCheckOut(e.target.value)} />
            </div>
          </div>

          <div style={{marginTop:10}}>
            <div className="space"><span>Nights</span><b>{nights}</b></div>
            <div className="space"><span>Subtotal</span><b>₹{total}</b></div>
            <div className="space"><span>Taxes (10%)</span><b>₹{Math.round(total*0.1)}</b></div>
            <hr/>
            <div className="space"><b>Total</b><b>₹{Math.round(total*1.1)}</b></div>
          </div>

          <button className="btn" style={{width:"100%",marginTop:12}} onClick={reserve}>
            Reserve
          </button>

          {msg && <p style={{marginTop:10}}>{msg}</p>}
        </div>
      </div>
    </div>
  );
}
