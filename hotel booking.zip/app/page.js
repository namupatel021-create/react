
'use client';
import { useState } from 'react';
import { listings } from './data/listings';
import Navbar from './components/Navbar';
import Card from './components/Card';

export default function Home(){
  const [search,setSearch] = useState("");

  const filtered = listings.filter(l =>
    l.city.toLowerCase().includes(search.toLowerCase()) ||
    l.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <Navbar search={search} setSearch={setSearch} />
      <div className="container">
        <div className="grid">
          {filtered.map(item => <Card key={item.id} item={item} />)}
        </div>
      </div>
    </div>
  );
}
