
export const listings = [
  {
    id: "1",
    title: "Beach House Goa",
    city: "Goa",
    price: 5000,
    rooms: 2,
    images: [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511",
      "https://images.unsplash.com/photo-1496417263034-38ec4f0b665a",
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688",
      "https://images.unsplash.com/photo-1493809842364-78817add7ffb"
    ],
    amenities: ["WiFi","Pool","AC","Kitchen"]
  },
  {
    id: "2",
    title: "Luxury Villa Ahmedabad",
    city: "Ahmedabad",
    price: 8000,
    rooms: 1,
    images: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2",
      "https://images.unsplash.com/photo-1507089947368-19c1da9775ae",
      "https://images.unsplash.com/photo-1505691723518-36a5ac3b2c4b",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511"
    ],
    amenities: ["WiFi","AC","Parking"]
  },
  {
    id: "3",
    title: "Mountain Cabin Manali",
    city: "Manali",
    price: 4000,
    rooms: 3,
    images: [
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f",
      "https://images.unsplash.com/photo-1519710164239-da123dc03ef4",
      "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511"
    ],
    amenities: ["WiFi","Heater","View"]
  }
];
