
'use client';
import Link from 'next/link';
import { motion } from 'framer-motion';

export default function Card({item}){
  return (
    <motion.div className="card" whileHover={{scale:1.02}}>
      <Link href={`/property/${item.id}`}>
        <img src={item.images[0]} style={{width:"100%",height:180,objectFit:"cover"}}/>
      </Link>
      <div style={{padding:12}}>
        <div className="space">
          <h3 style={{margin:"6px 0"}}>{item.title}</h3>
          <span className="badge">{item.city}</span>
        </div>
        <p style={{margin:0}}>₹{item.price}/night</p>
      </div>
    </motion.div>
  );
}
