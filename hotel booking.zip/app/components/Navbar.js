
'use client';
export default function Navbar({search, setSearch}){
  return (
    <div className="navbar">
      <div className="container space">
        <h2 style={{color:"#ff385c",margin:0}}>Airbnb</h2>
        <input
          className="input"
          placeholder="Search city (Goa, Ahmedabad, Manali)"
          value={search}
          onChange={(e)=>setSearch(e.target.value)}
        />
      </div>
    </div>
  );
}
