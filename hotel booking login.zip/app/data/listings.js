
export const listings=[
{id:'1',title:'Goa Beach',price:5000,img:'https://images.unsplash.com/photo-1505691938895-1758d7feb511'},
{id:'2',title:'Ahmedabad Villa',price:7000,img:'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2'}
];
