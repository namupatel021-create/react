
'use client';
export default function Dashboard(){
 const user=JSON.parse(localStorage.getItem('user')||'{}');
 return (
  <div style={{padding:20}}>
   <h2>👤 Dashboard</h2>
   <p>Email: {user.email}</p>
   <p>Your bookings will appear here (demo).</p>
  </div>
 );
}
