
'use client';
import {useState} from 'react';
import {useRouter} from 'next/navigation';

export default function Login(){
 const [email,setEmail]=useState('');
 const [password,setPassword]=useState('');
 const router=useRouter();

 const login=()=>{
  if(!email.includes('@')||password.length<6) return alert('Invalid');
  localStorage.setItem('user',JSON.stringify({email}));
  router.push('/');
 };

 return (
  <div style={{display:'flex',height:'100vh',justifyContent:'center',alignItems:'center'}}>
   <div className='card'>
    <h2>Login</h2>
    <input placeholder="Email" onChange={e=>setEmail(e.target.value)}/>
    <input type="password" placeholder="Password" onChange={e=>setPassword(e.target.value)}/>
    <button onClick={login}>Login</button>
   </div>
  </div>
 );
}
