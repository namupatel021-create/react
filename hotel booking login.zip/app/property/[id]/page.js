
'use client';
import {useParams,useRouter} from 'next/navigation';
import {useState,useEffect} from 'react';
import {listings} from '../../data/listings';

export default function Property(){
 const {id}=useParams();
 const router=useRouter();
 const item=listings.find(l=>l.id===id);

 const [inDate,setIn]=useState('');
 const [outDate,setOut]=useState('');
 const [msg,setMsg]=useState('');

 const book=()=>{
  if(!inDate||!outDate) return setMsg('Select dates');
  setMsg('🎉 Booking Confirmed!');
 };

 if(!item) return <div>Not found</div>;

 return (
  <div style={{padding:20}}>
   <h2>{item.title}</h2>
   <img src={item.img} style={{width:300}}/>
   <div>
    <input type='date' onChange={e=>setIn(e.target.value)}/>
    <input type='date' onChange={e=>setOut(e.target.value)}/>
    <button onClick={book}>Reserve</button>
   </div>
   {msg && <p>{msg}</p>}
   <button onClick={()=>router.push('/dashboard')}>Go Dashboard</button>
  </div>
 );
}
