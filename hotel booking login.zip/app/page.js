
'use client';
import {useEffect,useState} from 'react';
import {useRouter} from 'next/navigation';
import {listings} from './data/listings';

export default function Home(){
 const router=useRouter();
 const [data,setData]=useState([]);

 useEffect(()=>{
  const user=localStorage.getItem('user');
  if(!user) router.push('/login');
  setData(listings);
 },[]);

 return (
  <div style={{padding:20}}>
   <h1>🏠 Explore Stays</h1>
   {data.map(l=>(
    <div key={l.id} className='card'>
     <img src={l.img} style={{width:200}}/>
     <h3>{l.title}</h3>
     <p>₹{l.price}/night</p>
     <button onClick={()=>router.push('/property/'+l.id)}>View</button>
    </div>
   ))}
  </div>
 );
}
