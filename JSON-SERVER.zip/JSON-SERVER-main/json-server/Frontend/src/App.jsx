// import React, { useEffect, useState } from 'react'
// import axios from 'axios'

// function App() {
//   const [Students, setStudents] = useState([])
//   const [Name, setName] = useState("")
//   const [Course, setCourse] = useState("")
//   const [editId, setEditId] = useState(null)

//   const API = "http://localhost:2930/students"

//   const showData = async () => {
//     const res = await axios.get(API)
//     setStudents(res.data)
//   }

//   const deleteStudent = async (id) => {
//     await axios.delete(`${API}/${id}`)
//     showData()
//   }

//   const editStudent = async (student) => {
//     setName(student.name)
//     setCourse(student.course)
//     setEditId(student.id)
//   }

//   useEffect(() => {
//     showData()
//   }, [])

//   const addStudent = async (e) => {
//     e.preventDefault()

//     if (!Name || !Course) {
//       alert("Please fill the details")
//       return
//     }

//     if (editId) {

//       await axios.put(`${API}/${editId}`, {
//         name: Name,
//         course: Course
//       })
//       setEditId(null)
//     } else {

//       await axios.post(API, {
//         name: Name,
//         course: Course
//       })
//     }

//     setName("")
//     setCourse("")
//     showData()
//   }

//   return (
//     <>
//       <form onSubmit={addStudent}>
//         <input
//           type="text"
//           placeholder='Name'
//           value={Name}
//           onChange={(e) => setName(e.target.value)}
//         />

//         <input
//           type="text"
//           placeholder='Course'
//           value={Course}
//           onChange={(e) => setCourse(e.target.value)}
//         />

//         <button type="submit">
//           {editId ? "Update" : "Add"} Student
//         </button>
//       </form>

//       <h1>Student List</h1>

//       {Students.map((student) => (
//         <h2 key={student.id}>
//           {student.name} - {student.course} - {student.id}

//           <button onClick={() => deleteStudent(student.id)}>
//             Delete
//           </button>

//           <button onClick={() => editStudent(student)}>
//             Edit
//           </button>
//         </h2>
//       ))}
//     </>
//   )
// }

// export default App

import React, { useEffect, useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  const [Students, setStudents] = useState([]);
  const [Name, setName] = useState("");
  const [Course, setCourse] = useState("");
  const [editId, setEditId] = useState(null);
  const [errors, setErrors] = useState({});
  const [search, setSearch] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");
  const [showPopup, setShowPopup] = useState(false);

  const API = "http://localhost:2930/students";

  const showData = async () => {
    const res = await axios.get(API);
    setStudents(res.data);
  };

  useEffect(() => {
    showData();
  }, []);

  // ✅ Validation
  const validate = () => {
    let err = {};

    if (!Name.trim()) err.name = "Name is required";
    else if (Name.length < 3) err.name = "Min 3 characters";

    if (!Course.trim()) err.course = "Course is required";

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const addStudent = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    await axios.post(API, { name: Name, course: Course });
    toast.success("Student Added 🎉");

    setName("");
    setCourse("");
    showData();
  };

  const updateStudent = async () => {
    if (!validate()) return;

    await axios.put(`${API}/${editId}`, {
      name: Name,
      course: Course,
    });

    toast.success("Student Updated ✅");
    setShowPopup(false);
    setEditId(null);
    setName("");
    setCourse("");
    showData();
  };

  const deleteStudent = async (id) => {
    await axios.delete(`${API}/${id}`);
    toast.error("Student Deleted ❌");
    showData();
  };

  const editStudent = (student) => {
    setName(student.name);
    setCourse(student.course);
    setEditId(student.id);
    setShowPopup(true);
  };

  // ✅ Search + Sort
  const filteredStudents = Students.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()),
  ).sort((a, b) =>
    sortOrder === "asc"
      ? a.name.localeCompare(b.name)
      : b.name.localeCompare(a.name),
  );

  return (
    <div className="container mt-5">
      <ToastContainer />

      {/* ✅ ADD FORM */}
      <div className="row justify-content-center mb-4">
        <div className="col-md-5 col-lg-4">
          <div className="card shadow p-4">
            <h4 className="text-center mb-3">Add Student</h4>

            <form onSubmit={addStudent}>
              <input
                type="text"
                className="form-control mb-2"
                placeholder="Name"
                value={Name}
                onChange={(e) => setName(e.target.value)}
              />
              {errors.name && (
                <small className="text-danger">{errors.name}</small>
              )}

              <input
                type="text"
                className="form-control mt-2 mb-2"
                placeholder="Course"
                value={Course}
                onChange={(e) => setCourse(e.target.value)}
              />
              {errors.course && (
                <small className="text-danger">{errors.course}</small>
              )}

              <button className="btn btn-primary w-100 mt-2">
                Add Student
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* ✅ SEARCH + SORT */}
      <div className="d-flex justify-content-between mb-3">
        <input
          type="text"
          className="form-control w-50"
          placeholder="Search by name..."
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          className="form-select w-25"
          onChange={(e) => setSortOrder(e.target.value)}
        >
          <option value="asc">A → Z</option>
          <option value="desc">Z → A</option>
        </select>
      </div>

      {/* ✅ TABLE */}
   <table className="table table-bordered text-center">
  <thead className="table-dark">
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Course</th>
      <th>Actions</th>
    </tr>
  </thead>

  <tbody>
    {filteredStudents && filteredStudents.length > 0 ? (
      filteredStudents.map((student) => (
        <tr key={student.id}>
          <td>{student.id}</td>
          <td>{student.name}</td>
          <td>{student.course}</td>
          <td>
            <button
              className="btn btn-danger btn-sm me-2"
              onClick={() => deleteStudent(student.id)}
            >
              Delete
            </button>

            <button
              className="btn btn-warning btn-sm"
              onClick={() => editStudent(student)}
            >
              Edit
            </button>
          </td>
        </tr>
      ))
    ) : (
      <tr>
        <td colSpan="4" className="text-danger fw-bold">
        No Data Found
      </td>
      </tr>
    )}
  </tbody>
</table>

      {/* ✅ CUSTOM CENTER POPUP */}
      {showPopup && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            className="bg-white p-4 rounded shadow"
            style={{ width: "300px" }}
          >
            <h5 className="text-center mb-3">Edit Student</h5>

            <input
              type="text"
              className="form-control mb-2"
              value={Name}
              onChange={(e) => setName(e.target.value)}
            />
            {errors.name && (
              <small className="text-danger">{errors.name}</small>
            )}

            <input
              type="text"
              className="form-control mt-2"
              value={Course}
              onChange={(e) => setCourse(e.target.value)}
            />
            {errors.course && (
              <small className="text-danger">{errors.course}</small>
            )}

            <div className="d-flex justify-content-between mt-3">
              <button
                className="btn btn-secondary"
                onClick={() => setShowPopup(false)}
              >
                Cancel
              </button>

              <button className="btn btn-primary" onClick={updateStudent}>
                Update
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
