import { Link } from "react-router-dom";
export default function Navbar() {
  return (
    <nav className="navbar navbar-dark bg-dark p-3">
      <Link className="navbar-brand" to="/">Hotel</Link>
      <div>
        <Link className="btn btn-light m-1" to="/">Rooms</Link>
        <Link className="btn btn-light m-1" to="/reserve">Reserve</Link>
        <Link className="btn btn-light m-1" to="/reservations">Reservations</Link>
      </div>
    </nav>
  );
}
