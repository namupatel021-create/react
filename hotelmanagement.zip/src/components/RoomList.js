import { useEffect, useState } from "react";
import axios from "axios";

export default function RoomList() {
  const [rooms, setRooms] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3001/rooms")
      .then(res => setRooms(res.data));
  }, []);

  return (
    <div className="container">
      <h2>Rooms</h2>
      {rooms.map(room => (
        <div key={room.id} className="card p-2 m-2">
          {room.type} - ${room.price}
        </div>
      ))}
    </div>
  );
}
