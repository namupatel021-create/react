import { useState } from "react";
import axios from "axios";

export default function ReservationForm() {
  const [form, setForm] = useState({ roomId: "", checkIn: "", checkOut: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:3001/reservations", form);
    alert("Reserved!");
  };

  return (
    <form onSubmit={handleSubmit} className="container">
      <input className="form-control m-2" placeholder="Room ID"
        onChange={e => setForm({...form, roomId: e.target.value})} />
      <input className="form-control m-2" type="date"
        onChange={e => setForm({...form, checkIn: e.target.value})} />
      <input className="form-control m-2" type="date"
        onChange={e => setForm({...form, checkOut: e.target.value})} />
      <button className="btn btn-primary m-2">Reserve</button>
    </form>
  );
}
