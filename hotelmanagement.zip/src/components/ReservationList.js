import { useEffect, useState } from "react";
import axios from "axios";

export default function ReservationList() {
  const [reservations, setReservations] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3001/reservations")
      .then(res => setReservations(res.data));
  }, []);

  return (
    <div className="container">
      <h2>Reservations</h2>
      {reservations.map(r => (
        <div key={r.id} className="card p-2 m-2">
          Room {r.roomId} | {r.checkIn} → {r.checkOut}
        </div>
      ))}
    </div>
  );
}
