// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDFG-bJpl1UbtXh1xfGsBaxMFzJ2YHOTV4",
  authDomain: "authentication-8e175.firebaseapp.com",
  databaseURL: "https://authentication-8e175-default-rtdb.firebaseio.com",
  projectId: "authentication-8e175",
  storageBucket: "authentication-8e175.firebasestorage.app",
  messagingSenderId: "1001870835574",
  appId: "1:1001870835574:web:73c9e79c7d342811228457",
  measurementId: "G-K6EF38BRFS"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export default auth