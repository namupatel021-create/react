import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./Layout/Navbar";
import BlogList from "./pages/BlogList";
import BlogForm from "./pages/BlogForm";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.js";
import PrivateRoute from "./Layout/PrivateRoute";
import Login from "./pages/Login";

const App = () => {
  return (
    <>
      <Router>
        <Navbar />
        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={<Login />} />

          {/* Protected Routes */}
          <Route element={<PrivateRoute />}>
            <Route path="/" element={<BlogList />} />
            <Route path="/addBlog" element={<BlogForm />} />
            <Route path="/updateBlog/:id" element={<BlogForm />} />
          </Route>
        </Routes>
      </Router>
    </>
  );
};

export default App;
