import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { Api } from "../Layout/Api";

export const addBlog = createAsyncThunk('addBlog', async (data) => {
    try {
        const res = await Api.post('BlogList', data)
        // console.log(res.data)
        return res.data
    } catch (error) {
        console.log(error)
    }
})

export const viewBlog = createAsyncThunk('viewBlog', async () => {
    try {
        const res = await Api.get('BlogList')
        // console.log(res.data)
        return res.data
    } catch (error) {
        console.log(error)
    }
})

export const deleteBlog = createAsyncThunk('deleteBlog', async (id) => {
    try {
        const res = await Api.delete(`BlogList/${id}`)
        // console.log(res.data)
        return res.data
    } catch (error) {
        console.log(error)
    }
})

export const updateBlog = createAsyncThunk('updateBlog', async (data) => {
    try {
        const { id } = data
        const res = await Api.put(`BlogList/${id}`, data)
        // console.log(res.data)
        return res.data
    } catch (error) {
        console.log(error)
    }
})

const BlogSlice = createSlice({
    name: 'blog',
    initialState: {
        blogList: []
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(addBlog.fulfilled, (state, action) => {
                state.blogList.push(action.payload)
            })
            .addCase(viewBlog.fulfilled, (state, action) => {
                state.blogList = action.payload
            })
            .addCase(deleteBlog.fulfilled, (state, action) => {
                const { id } = action.payload
                const filterData = state.blogList.filter(blog => blog.id !== id)
                state.blogList = filterData
            })
            .addCase(updateBlog.fulfilled, (state, action) => {
                const { id } = action.payload
                const index = state.blogList.find(blog => blog.id === id)
                if (index != -1) { 
                    state.blogList[index] = action.payload
                }
            })
    }
})

export default BlogSlice.reducer