import { configureStore } from "@reduxjs/toolkit";
import BlogSlice from "./BlogSlice"

const Store = configureStore({
    reducer:{
        blogs:BlogSlice
    }
})

export default Store