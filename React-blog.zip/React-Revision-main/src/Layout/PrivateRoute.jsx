import { onAuthStateChanged } from "firebase/auth";
import React, {  useEffect, useState } from "react";
import { Navigate, Outlet } from "react-router-dom";
import auth from "../../firebase";

const PrivateRoute = () => {

  const [isAuth, setAuth] = useState(null);
  useEffect(() => {
    onAuthStateChanged(auth)
      .then((user) => setAuth(user))
      .catch((err) => console.log(err));
  }, []);

  return isAuth == null ?  <Navigate to="/login" /> : <Outlet/>   
};

export default PrivateRoute;
