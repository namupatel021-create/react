import {
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
} from "firebase/auth";
import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import auth from "../../firebase";

const Navbar = () => {
  const [isAuth, setAuth] = useState(null);

  const signUp = () => {
    const provider = new GoogleAuthProvider();
    signInWithPopup(auth, provider)
      .then((res) => {
        console.log(res);
        alert("Signin Sucessfully ");
      })
      .catch((err) => console.log(err));
  };

  function getAuth() {
    onAuthStateChanged(auth, (user) => {
      setAuth(user);
    });
  }

  useEffect(() => {
    getAuth();
  }, [auth]);

  function logOut() {
    signOut(auth)
      .then((res) => {
        console.log(res);
      })
      .catch((err) => console.log(err));
  }

  return (
    <>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
          <NavLink className="navbar-brand" to="/">
            Navbar
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div className="navbar-nav">
              <NavLink className="nav-link" to="/addBlog">
                Add Blog
              </NavLink>
              <NavLink className="nav-link" aria-current="page" to="/">
                View Blog
              </NavLink>
              {isAuth == null ? (
                <button onClick={signUp} className="btn btn-warning">
                  Signin with Google
                </button>
              ) : (
                <button onClick={logOut} className="btn btn-danger">
                  Logout
                </button>
              )}

              {isAuth != null ? (
                <div className="dropdown">
                  <button
                    className="btn btn-secondary dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Profile
                  </button>
                  <ul className="dropdown-menu">
                    <li>{isAuth.displayName}</li>
                    <li>{isAuth.email}</li>
                    <li>
                      <img src={isAuth.photoUrl} alt={isAuth.displayName} width={100} height={100}/>
                    </li>
                  </ul>
                </div>
              ) : (
                ""
              )}
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
