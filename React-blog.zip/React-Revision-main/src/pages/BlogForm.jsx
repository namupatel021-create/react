import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { addBlog, updateBlog } from "../feature/BlogSlice";
import { Navigate, useNavigate, useParams } from "react-router-dom";

const BlogForm = () => {
  const { register, handleSubmit, reset } = useForm();
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const { id } = useParams();

  /////// update ////////////
  const { blogList } = useSelector((state) => state.blogs);
  useEffect(() => {
    const singleBlog = blogList.find((blog) => blog.id == id);
    reset(singleBlog);
  }, [id, dispatch]);

  ///////// Add Data //////////////
  function Add(data) {
    if (id == null) {
      dispatch(addBlog(data));
      alert("Data Inserted!!!!!!!!");
    } else {
      dispatch(updateBlog(data));
      alert("Data Updated!!!!!!!");
    }
    reset();
    Navigate("/");
  }

  return (
    <>
      <div className="col-md-6 mx-auto p-5 m-5 shadow">
        <h3 className="text-center">Blog Form</h3>
        <form onSubmit={handleSubmit(Add)}>
          <input
            type="text"
            {...register("name")}
            className=" form-control mt-4"
            placeholder="Blog Name"
          />
          <input
            type="text"
            {...register("title")}
            className=" form-control mt-4"
            placeholder="Blog Title"
          />
          <input
            type="url"
            {...register("url")}
            className=" form-control mt-4"
            placeholder="Blog Image URL"
          />
          <select {...register("category")} className="form-control mt-4">
            <option disabled aria-selected>
              --- Select ---
            </option>
            <option>Electronic</option>
            <option>Vehical</option>
            <option>Railway</option>
          </select>
          <button className="mt-4 btn btn-warning">
            {id == null ? "submit" : "Update"}
          </button>
        </form>
      </div>
    </>
  );
};

export default BlogForm;
