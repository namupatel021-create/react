import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteBlog, viewBlog } from "../feature/BlogSlice";
import { NavLink } from "react-router-dom";

const BlogList = () => {
  const dispatch = useDispatch();
  const { blogList } = useSelector((state) => state.blogs);

  const [search, setSearch] = useState("");
  const [sortType, setSortType] = useState("");

  ///////////// Delete Blog
  function Trash(id) {
    if (confirm("Do you want to delete this Blog???")) {
      dispatch(deleteBlog(id));
    }
  }

  useEffect(() => {
    dispatch(viewBlog());
  }, [dispatch]);

  // //////////Search Logic
  const finalBlogs = blogList
    ?.filter(
      (ele) =>
        ele.name.toLowerCase().includes(search.toLowerCase()) ||
        ele.title.toLowerCase().includes(search.toLowerCase()) ||
        ele.category.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => {
      if (sortType === "name-asc") {
        return a.name.localeCompare(b.name);
      }
      if (sortType === "name-desc") {
        return b.name.localeCompare(a.name);
      }
      if (sortType === "category") {
        return a.category.localeCompare(b.category);
      }
      return 0;
    });

  return (
    <>
      <div className="container my-5">
        <div className="row mb-4">
          <div className="col-6 mx-auto">
            {/* /////////////  Search Box ///////////*/}
            <input
              type="text"
              className="form-control shadow-sm "
              placeholder="Search by name, title or category..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          {/* /////////////// Sorting ///////////////// */}

          <div className="col-md-6 mx-auto">
            <select
              className="form-select shadow-sm"
              value={sortType}
              onChange={(e) => setSortType(e.target.value)}
            >
              <option value="">Sort Blogs</option>
              <option value="name-asc">Name (A-Z)</option>
              <option value="name-desc">Name (Z-A)</option>
              <option value="category">Category</option>
            </select>
          </div>
        </div>

        <div className="row g-4">
          {finalBlogs && finalBlogs.length > 0 ? (
            finalBlogs.map((ele) => (
              <div className="col-lg-4 col-md-6" key={ele.id}>
                <div className="card shadow border-0 h-100">
                  <img
                    src={ele.url}
                    alt={ele.title}
                    className="card-img-top"
                    style={{ height: "200px", objectFit: "cover" }}
                  />

                  <div className="card-body">
                    <h5 className="fw-bold">{ele.name}</h5>
                    <p className="text-muted">{ele.title}</p>
                    <p className="text-muted">{ele.category}</p>

                    <div className="btn-group w-100">
                      <button
                        className="btn btn-danger"
                        onClick={() => Trash(ele.id)}
                      >
                        Delete
                      </button>

                      <NavLink
                        to={`/updateBlog/${ele.id}`}
                        className="btn btn-info"
                      >
                        Update
                      </NavLink>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <h4 className="text-center text-muted">No blogs found</h4>
          )}
        </div>
      </div>
    </>
  );
};

export default BlogList;
